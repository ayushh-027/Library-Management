package com.library.controller;

import com.library.model.Book;
import com.library.service.BookService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/books")
public class BookController {

    private final BookService service;

    public BookController(BookService service) {
        this.service = service;
    }

    // (b) Add a new book -> 201 Created
    @PostMapping
    public ResponseEntity<Book> addBook(@Valid @RequestBody Book book) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.addBook(book));
    }

    // (c) Retrieve all books -> 200 OK
    @GetMapping
    public List<Book> getAllBooks() {
        return service.getAllBooks();
    }

    // (c) Retrieve a book by ID -> 200 OK, or 404 Not Found
    @GetMapping("/{id}")
    public Book getBookById(@PathVariable("id") Integer id) {
        return service.getBookById(id);
    }

    // (d) Update a book -> 200 OK, or 404 Not Found
    @PutMapping("/{id}")
    public Book updateBook(@PathVariable("id") Integer id, @Valid @RequestBody Book book) {
        return service.updateBook(id, book);
    }

    // (e) Delete a book -> 200 OK with a message, or 404 Not Found if the book does not exist
    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, String>> deleteBook(@PathVariable("id") Integer id) {
        service.deleteBook(id);
        Map<String, String> response = new LinkedHashMap<>();
        response.put("message", "Book with ID " + id + " deleted successfully");
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }
}
