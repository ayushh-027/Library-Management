package com.library.exception;

public class DuplicateBookException extends RuntimeException {
    public DuplicateBookException(Integer id) {
        super("Book with ID " + id + " already exists");
    }
}
