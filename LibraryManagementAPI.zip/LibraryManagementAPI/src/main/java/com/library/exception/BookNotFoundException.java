package com.library.exception;

public class BookNotFoundException extends RuntimeException {
    public BookNotFoundException(Integer id) {
        super("Book with ID " + id + " not found");
    }
}
