package com.library.service;

import com.library.exception.BookNotFoundException;
import com.library.exception.DuplicateBookException;
import com.library.model.Book;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentSkipListMap;

@Service
public class BookService {

    // Collection used to store the books: a Map from book ID to Book.
    // ConcurrentSkipListMap keeps the books sorted by ID and is safe to use from many requests.
    private final Map<Integer, Book> books = new ConcurrentSkipListMap<>();

    // (b) Add a new book
    public synchronized Book addBook(Book book) {
        if (book.getId() == null) {
            book.setId(nextId());
        } else if (books.containsKey(book.getId())) {
            throw new DuplicateBookException(book.getId());
        }
        book.setTitle(book.getTitle().trim());
        book.setAuthor(book.getAuthor().trim());
        book.setCategory(book.getCategory().trim());
        books.put(book.getId(), book);
        return book;
    }

    // (c) Retrieve all books (returned as a List, ordered by ID)
    public List<Book> getAllBooks() {
        return new ArrayList<>(books.values());
    }

    // (c) Retrieve one book by ID
    public Book getBookById(Integer id) {
        Book book = books.get(id);
        if (book == null) {
            throw new BookNotFoundException(id);
        }
        return book;
    }

    // (d) Update title, author, category and available copies
    public synchronized Book updateBook(Integer id, Book updated) {
        Book existing = getBookById(id);
        existing.setTitle(updated.getTitle().trim());
        existing.setAuthor(updated.getAuthor().trim());
        existing.setCategory(updated.getCategory().trim());
        existing.setAvailableCopies(updated.getAvailableCopies());
        return existing;
    }

    // (e) Delete a book by ID
    public synchronized void deleteBook(Integer id) {
        if (books.remove(id) == null) {
            throw new BookNotFoundException(id);
        }
    }

    // Next ID = highest existing ID + 1
    private Integer nextId() {
        return books.keySet().stream().max(Integer::compare).orElse(0) + 1;
    }
}
